using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ETSU_Housing.Pages
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
